// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from final_project:srv/SetColor.idl
// generated code does not contain a copyright notice

#ifndef FINAL_PROJECT__SRV__DETAIL__SET_COLOR__BUILDER_HPP_
#define FINAL_PROJECT__SRV__DETAIL__SET_COLOR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "final_project/srv/detail/set_color__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace final_project
{

namespace srv
{

namespace builder
{

class Init_SetColor_Request_color
{
public:
  Init_SetColor_Request_color()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::final_project::srv::SetColor_Request color(::final_project::srv::SetColor_Request::_color_type arg)
  {
    msg_.color = std::move(arg);
    return std::move(msg_);
  }

private:
  ::final_project::srv::SetColor_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::final_project::srv::SetColor_Request>()
{
  return final_project::srv::builder::Init_SetColor_Request_color();
}

}  // namespace final_project


namespace final_project
{

namespace srv
{

namespace builder
{

class Init_SetColor_Response_success
{
public:
  Init_SetColor_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::final_project::srv::SetColor_Response success(::final_project::srv::SetColor_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::final_project::srv::SetColor_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::final_project::srv::SetColor_Response>()
{
  return final_project::srv::builder::Init_SetColor_Response_success();
}

}  // namespace final_project

#endif  // FINAL_PROJECT__SRV__DETAIL__SET_COLOR__BUILDER_HPP_
