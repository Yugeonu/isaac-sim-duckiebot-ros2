// generated from rosidl_generator_c/resource/idl.h.em
// with input from final_project:srv/SetColor.idl
// generated code does not contain a copyright notice

#ifndef FINAL_PROJECT__SRV__SET_COLOR_H_
#define FINAL_PROJECT__SRV__SET_COLOR_H_

#include "final_project/srv/detail/set_color__struct.h"
#include "final_project/srv/detail/set_color__functions.h"
#include "final_project/srv/detail/set_color__type_support.h"

#endif  // FINAL_PROJECT__SRV__SET_COLOR_H_
