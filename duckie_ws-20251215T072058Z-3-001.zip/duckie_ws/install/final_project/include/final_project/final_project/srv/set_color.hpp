// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef FINAL_PROJECT__SRV__SET_COLOR_HPP_
#define FINAL_PROJECT__SRV__SET_COLOR_HPP_

#include "final_project/srv/detail/set_color__struct.hpp"
#include "final_project/srv/detail/set_color__builder.hpp"
#include "final_project/srv/detail/set_color__traits.hpp"
#include "final_project/srv/detail/set_color__type_support.hpp"

#endif  // FINAL_PROJECT__SRV__SET_COLOR_HPP_
